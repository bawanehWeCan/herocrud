        <footer>
            <div class="footer clearfix mb-0 text-muted">

            </div>
        </footer>
    </div>

    <script src="{{ asset('mazer') }}/js/app.js"></script>
    @stack('js')
</body>

</html>
