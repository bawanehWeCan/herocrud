<div class="row mb-2">
    <?php if(isset($picture)): ?>
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-4 text-center">
                    <?php if($picture->image == null): ?>
                        <img src="https://via.placeholder.com/350?text=No+Image+Avaiable" alt="Image" class="rounded mb-2 mt-2" alt="Image" width="200" height="150" style="object-fit: cover">
                    <?php else: ?>
                        <img src="<?php echo e(asset('storage/uploads/images/' . $picture->image)); ?>" alt="Image" class="rounded mb-2 mt-2" width="200" height="150" style="object-fit: cover">
                    <?php endif; ?>
                </div>

                <div class="col-md-8">
                    <div class="form-group ms-3">
                        <label for="image"><?php echo e(__('Image')); ?></label>
                        <input type="file" name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image">

                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger">
                                <?php echo e($message); ?>

                           </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div id="imageHelpBlock" class="form-text">
                            <?php echo e(__('Leave the image blank if you don`t want to change it.')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="col-md-6">
            <div class="form-group">
                <label for="image"><?php echo e(__('Image')); ?></label>
                <input type="file" name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image" required>

                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <span class="text-danger">
                        <?php echo e($message); ?>

                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    <?php endif; ?>
    <div class="col-md-6">
        <div class="form-group">
            <label for="point-id"><?php echo e(__('Point')); ?></label>
            <select class="form-select <?php $__errorArgs = ['point_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="point_id" id="point-id" class="form-control" required>
                <option value="" selected disabled>-- <?php echo e(__('Select point')); ?> --</option>
                
                        <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($point->id); ?>" <?php echo e(isset($picture) && $picture->point_id == $point->id ? 'selected' : (old('point_id') == $point->id ? 'selected' : '')); ?>>
                                <?php echo e($point->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['point_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger">
                    <?php echo e($message); ?>

                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
</div><?php /**PATH D:\generator\resources\views/pictures/include/form.blade.php ENDPATH**/ ?>