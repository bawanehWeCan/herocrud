<?php $__env->startSection('title', __('Detail of Points')); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-8 order-md-1 order-last">
                    <h3><?php echo e(__('Points')); ?></h3>
                    <p class="text-subtitle text-muted">
                        <?php echo e(__('Detail of point.')); ?>

                    </p>
                </div>

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.breadcrumb','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <li class="breadcrumb-item">
                        <a href="/"><?php echo e(__('Dashboard')); ?></a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('points.index')); ?>"><?php echo e(__('Points')); ?></a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e(__('Detail')); ?>

                    </li>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>

        <section class="section">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                    <tr>
                                            <td class="fw-bold"><?php echo e(__('Name')); ?></td>
                                            <td><?php echo e($point->name); ?></td>
                                        </tr>
									<tr>
                                            <td class="fw-bold"><?php echo e(__('Address')); ?></td>
                                            <td><?php echo e($point->address); ?></td>
                                        </tr>
									<tr>
                                            <td class="fw-bold"><?php echo e(__('Phone')); ?></td>
                                            <td><?php echo e($point->phone); ?></td>
                                        </tr>
									<tr>
                                            <td class="fw-bold"><?php echo e(__('Connection')); ?></td>
                                            <td><?php echo e($point->connection); ?></td>
                                        </tr>
									<tr>
                                            <td class="fw-bold"><?php echo e(__('Speed')); ?></td>
                                            <td><?php echo e($point->speed); ?></td>
                                        </tr>
									<tr>
                                            <td class="fw-bold"><?php echo e(__('Price')); ?></td>
                                            <td><?php echo e($point->price); ?></td>
                                        </tr>
                                    <tr>
                                        <td class="fw-bold"><?php echo e(__('Created at')); ?></td>
                                        <td><?php echo e($point->created_at->format('d/m/Y H:i')); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="fw-bold"><?php echo e(__('Updated at')); ?></td>
                                        <td><?php echo e($point->updated_at->format('d/m/Y H:i')); ?></td>
                                    </tr>
                                </table>
                            </div>

                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary"><?php echo e(__('Back')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\generator\resources\views/points/show.blade.php ENDPATH**/ ?>