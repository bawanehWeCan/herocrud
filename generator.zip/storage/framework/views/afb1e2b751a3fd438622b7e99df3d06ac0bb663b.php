<td>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('picture view')): ?>
    <a href="<?php echo e(route('pictures.show', $model->id)); ?>" class="btn btn-outline-success btn-sm">
        <i class="fa fa-eye"></i>
    </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('picture edit')): ?>
        <a href="<?php echo e(route('pictures.edit', $model->id)); ?>" class="btn btn-outline-primary btn-sm">
            <i class="fa fa-pencil-alt"></i>
        </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('picture delete')): ?>
        <form action="<?php echo e(route('pictures.destroy', $model->id)); ?>" method="post" class="d-inline"
            onsubmit="return confirm('Are you sure to delete this record?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>

            <button class="btn btn-outline-danger btn-sm">
                <i class="ace-icon fa fa-trash-alt"></i>
            </button>
        </form>
    <?php endif; ?>
</td>
<?php /**PATH D:\generator\resources\views/pictures/include/action.blade.php ENDPATH**/ ?>