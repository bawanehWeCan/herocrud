<div class="row mb-2">
    
    <div class="col-md-5">
        <div class="form-group">
            <label for="model"><?php echo e(__('Model')); ?></label>
            <input type="text" name="model" id="model" class="form-control <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="<?php echo e(__('Product')); ?>" value="<?php echo e(old('model')); ?>" autofocus required>
            <small class="text-secondary"><?php echo e(__("Use '/' for generate a sub folder. e.g.: Main/Product.")); ?></small>
            <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    

    
    <div class="col-md-7">
        <p class="mb-2">Generate Type</p>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="generate_type" id="generate-type-1"
                value="<?php echo e(\Zzzul\Generator\Enums\GeneratorType::ALL->value); ?>" checked>
            <label class="form-check-label" for="generate-type-1">
                <?php echo e(__('All (Migration, Model, View, Controller, Route, & Request)')); ?>

            </label>
        </div>

        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="generate_type" id="generate-type-2"
                value="<?php echo e(\Zzzul\Generator\Enums\GeneratorType::ONLY_MODEL_AND_MIGRATION->value); ?>">
            <label class="form-check-label" for="generate-type-2">
                <?php echo e(__('Only Model & Migration')); ?>

            </label>
        </div>
    </div>
    

    <div class="col-md-6 mt-3">
        <h6><?php echo e(__('Table Fields')); ?></h6>
    </div>

    <div class="col-md-6 mt-3 d-flex justify-content-end">
        <button type="button" id="btn-add" class="btn btn-success">
            <i class="fas fa-plus"></i>
            <?php echo e(__('Add')); ?>

        </button>
    </div>

    
    <div class="col-md-12">
        <table class="table table-striped table-hover table-sm" id="tbl-field">
            <thead>
                <tr>
                    <th width="30">#</th>
                    <th><?php echo e(__('Field name')); ?></th>
                    <th><?php echo e(__('Column Type')); ?></th>
                    <th width="310"><?php echo e(__('Length')); ?></th>
                    <th><?php echo e(__('Input Type')); ?></th>
                    <th><?php echo e(__('Required')); ?></th>
                    <th><?php echo e(__('Action')); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr draggable="true" ondragstart="dragStart()" ondragover="dragOver()" style="cursor: move;">
                    <td>1</td>
                    <td>
                        <div class="form-group">
                            <input type="text" name="fields[]" class="form-control"
                                placeholder="<?php echo e(__('Field Name')); ?>" required>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <select name="column_types[]" class="form-select form-column-types" required>
                                <option value="" disabled selected>--<?php echo e(__('Select column type')); ?>--</option>
                                <?php $__currentLoopData = ['string', 'integer', 'text', 'bigInteger', 'boolean', 'char', 'date', 'time', 'year', 'dateTime', 'decimal', 'double', 'enum', 'float', 'foreignId', 'tinyInteger', 'mediumInteger', 'tinyText', 'mediumText', 'longText']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>"><?php echo e(ucwords($type)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="hidden" name="select_options[]" class="form-option">
                            <input type="hidden" name="constrains[]" class="form-constrain">
                            <input type="hidden" name="foreign_ids[]" class="form-foreign-id">
                        </div>
                    </td>
                    <td>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="number" name="min_lengths[]" class="form-control form-min-lengths"
                                        min="1" placeholder="Min Length">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="number" name="max_lengths[]" class="form-control form-max-lengths"
                                        min="1" placeholder="Max Length">
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="form-group">
                            <select name="input_types[]" class="form-select form-input-types" required>
                                <option value="" disabled selected>-- <?php echo e(__('Select input type')); ?> --</option>
                                <option value="" disabled><?php echo e(__('Select the column type first')); ?></option>
                            </select>
                        </div>
                        <input type="hidden" name="mimes[]" class="form-mimes">
                        <input type="hidden" name="file_types[]" class="form-file-types">
                        <input type="hidden" name="files_sizes[]" class="form-file-sizes">
                        <input type="hidden" name="steps[]" class="form-step" placeholder="step">
                    </td>
                    <td class="mt-0 pt-0">
                        <div class="form-check form-switch form-control-lg">
                            <input class="form-check-input switch-requireds" type="checkbox" id="switch-1"
                                name="requireds[]" checked>
                        </div>
                        <input type="hidden" name="default_values[]" class="form-default-value"
                            placeholder="<?php echo e(__('Default Value (optional)')); ?>">
                    </td>
                    <td>
                        <button type="button" class="btn btn-outline-danger btn-sm btn-delete" disabled>
                            <i class="fa fa-trash-alt"></i>
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    

    <h6 class="mt-3"><?php echo e(__('Sidebar Menus')); ?></h6>

    
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="select-header"><?php echo e(__('Header')); ?></label>
                    <select name="header" id="select-header" class="form-select" required>
                        <option value="" disabled selected>-- <?php echo e(__('Select header')); ?> --</option>
                        <option value="new"><?php echo e(__('Create a New Header')); ?></option>
                        <?php $__currentLoopData = config('generator.sidebars'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keySidebar => $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($keySidebar); ?>"><?php echo e($header['header']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group" id="input-menu">
                    <label for="select-menu"><?php echo e(__('Menu')); ?></label>
                    <select name="menu" id="select-menu" class="form-select" required disabled>
                        <option value="" disabled selected>-- <?php echo e(__('Select header first')); ?> --</option>
                    </select>
                    <small id="helper-text-menu"></small>
                </div>
            </div>
        </div>
    </div>
    

    <div id="col-new-menu" style="display: none;"></div>
</div>
<?php /**PATH D:\generator\vendor\zzzul\generator\src\Providers/../Resources/views/generators/include/form.blade.php ENDPATH**/ ?>