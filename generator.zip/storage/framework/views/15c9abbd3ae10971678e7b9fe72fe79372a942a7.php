<td>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('point view')): ?>
    <a href="<?php echo e(route('points.show', $model->id)); ?>" class="btn btn-outline-success btn-sm">
        <i class="fa fa-eye"></i>
    </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('point edit')): ?>
        <a href="<?php echo e(route('points.edit', $model->id)); ?>" class="btn btn-outline-primary btn-sm">
            <i class="fa fa-pencil-alt"></i>
        </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('point delete')): ?>
        <form action="<?php echo e(route('points.destroy', $model->id)); ?>" method="post" class="d-inline"
            onsubmit="return confirm('Are you sure to delete this record?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>

            <button class="btn btn-outline-danger btn-sm">
                <i class="ace-icon fa fa-trash-alt"></i>
            </button>
        </form>
    <?php endif; ?>
</td>
<?php /**PATH D:\generator\resources\views/points/include/action.blade.php ENDPATH**/ ?>