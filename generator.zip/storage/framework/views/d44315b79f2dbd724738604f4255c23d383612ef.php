        <footer>
            <div class="footer clearfix mb-0 text-muted">

            </div>
        </footer>
    </div>

    <script src="<?php echo e(asset('mazer')); ?>/js/app.js"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH D:\generator\resources\views/layouts/footer.blade.php ENDPATH**/ ?>