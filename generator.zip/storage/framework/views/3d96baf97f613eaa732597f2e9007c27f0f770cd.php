

<?php $__env->startSection('title', __('Log in')); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('mazer')); ?>/css/pages/auth.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row h-100">
        <div class="col-lg-6 col-12">
            <div id="auth-left">
                <div class="auth-logo">
                    <a href="/">
                        <img src="<?php echo e(asset('mazer')); ?>/images/logo/logo.svg" alt="Logo">
                    </a>
                </div>

                <h1 class="auth-title"><?php echo e(__('Log in.')); ?></h1>
                <p class="auth-subtitle mb-3"><?php echo e(__('Log in with your data that you entered during registration.')); ?></p>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible show fade">
                        <ul class="ms-0 mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <p><?php echo e($error); ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible show fade">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group position-relative has-icon-left mb-4">
                        <input type="text" class="form-control form-control-xl <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="email" autocomplete="email" placeholder="Email" required autofocus>
                        <div class="form-control-icon">
                            <i class="bi bi-person"></i>
                        </div>
                    </div>

                    <div class="form-group position-relative has-icon-left mb-4">
                        <input type="password" class="form-control form-control-xl <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            placeholder="Password" name="password" autocomplete="current-password" required>
                        <div class="form-control-icon">
                            <i class="bi bi-shield-lock"></i>
                        </div>
                    </div>

                    <div class="form-check form-check-lg d-flex align-items-end">
                        <input class="form-check-input me-2" type="checkbox" value="" name="remember" id="remember"
                            <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <label class="form-check-label text-gray-600" for="remember">
                            Keep me logged in
                        </label>
                    </div>

                    <button class="btn btn-primary btn-block btn-lg shadow-lg mt-3"><?php echo e(__('Log in')); ?></button>
                </form>

                <div class="text-center mt-4 text-lg fs-4">
                    <p class="text-gray-600"><?php echo e(__("Don't have an account")); ?>?
                        <a href="/register" class="font-bold">
                            <?php echo e(__('Sign up.')); ?>

                        </a>
                    </p>

                    <?php if(Route::has('password.request')): ?>
                        <p>
                            <a class="font-bold" href="<?php echo e(route('password.request')); ?>">
                                <?php echo e(__('Forgot password')); ?>?
                            </a>.
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-6 d-none d-lg-block">
            <div id="auth-right">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\generator\resources\views/auth/login.blade.php ENDPATH**/ ?>