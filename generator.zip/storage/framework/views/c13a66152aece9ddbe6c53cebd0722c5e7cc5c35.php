<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('mazer')); ?>/css/main/app.css">
    <?php echo $__env->yieldPushContent('css'); ?>
    <link rel="shortcut icon" href="<?php echo e(asset('mazer')); ?>/images/logo/favicon.svg" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo e(asset('mazer')); ?>/images/logo/favicon.png" type="image/png">
</head>
</head>

<body>
    <div id="auth">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('mazer')); ?>/js/app.js"></script>
</body>

</html>
<?php /**PATH D:\generator\resources\views/layouts/auth.blade.php ENDPATH**/ ?>